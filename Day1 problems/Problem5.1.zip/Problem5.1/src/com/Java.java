package com;

public class Java {
	public static void main(String[] args) {
		
		
		String txt= "JAVA is Simple";
		
		System.out.println(txt.toUpperCase()); //UpperCase
		
		System.out.println(txt.toLowerCase()); //LowerCase
		
		
		String[] words=txt.split("\\s");	//1st words of letter
		for(String w:words){  
			System.out.print(w.charAt(0)); 
			System.out.print(" ");
		}

	}
}
	
	
