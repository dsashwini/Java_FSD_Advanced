import java.util.Scanner;
public class Rectangle {	
	void input() {
		Scanner in=new Scanner(System.in);
		System.out.print("Enter length of rectangle: ");
		length=in.nextInt();
		System.out.print("Enter breadth of rectangle: ");
		breadth=in.nextInt();		
	}
	void calculate() {
		area=length*breadth;
	}
	void display() {
		System.out.println("Area of Rectangle="+area);
	}
	
	private int length;
	public int getLength() {
		return length;
	}
	public void setLength(int newLength) {
		length=newLength;
	}
	private int breadth;
	public int getBreadth() {
		return breadth;
	}
	public void setBreadth(int newBreadth) {
		breadth=newBreadth;
	}
	private int area;
	public int getArea() {
		return area;
	}
	public void setArea(int newArea) {
		area=newArea;
	}
	public Rectangle() {
	int length;
	int breadth;
	int area;
	
	
	}

}