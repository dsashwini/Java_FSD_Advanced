
public class TestRectangle {	
	public static void main(String[] args) {
		Rectangle s1=new Rectangle();
		Rectangle s2=new Rectangle();
		Rectangle s3=new Rectangle();
		Rectangle s4=new Rectangle();		
		Rectangle s5=new Rectangle();
		s1.input();
		s2.input();
		s3.input();
		s4.input();
		s5.input();
		s1.calculate();
		s2.calculate();
		s3.calculate();
		s4.calculate();
		s5.calculate();
		s1.display();
		s2.display();
		s3.display();
		s4.display();
		s5.display();
		
		
		
		
		
		
	}

}
