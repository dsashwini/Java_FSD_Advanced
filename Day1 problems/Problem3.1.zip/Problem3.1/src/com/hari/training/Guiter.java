package com.hari.training;

public class Guiter extends Instrument {

	@Override
	public void play() {
		System.out.println("Guitar is playing  tin  tin  tin");

	}

}